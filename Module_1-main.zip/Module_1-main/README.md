# Module_1

This is are notebook for Module 1, Python BAsics
THe 1st notebook is the theory
THe 2nd one is the notebook with Practice, with provided code to the tasks
